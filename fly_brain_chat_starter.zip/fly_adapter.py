"""
Bridge between the chat UI and the public fly-brain simulation.

The important design choice is that this file does NOT fake a neural response
and call it the connectome. If flybrain is unavailable, it clearly reports
"demo mode".

The public fly.ai project currently documents:
- 166,700 neurons
- 25.6 million connections
- MaleCNS v1.0 connectome
- leaky integrate-and-fire simulation
- sensory encoders -> connectome -> descending neurons -> decoder/readout

Because the upstream Python API may change, the exact encoder/decoder hookup
should be made here after installing the version you want to use.
"""

try:
    import flybrain  # type: ignore
    HAVE_FLYBRAIN = True
except Exception:
    flybrain = None
    HAVE_FLYBRAIN = False


class FlyBrainAdapter:
    def __init__(self):
        self.real_brain_available = HAVE_FLYBRAIN

    def _encode_text(self, text):
        """Turn language into a tiny, explicit sensory-like representation.

        This is an interface layer, not a claim that the fly understands English.
        """
        t = text.lower()
        return {
            "left": any(w in t for w in ("left",)),
            "right": any(w in t for w in ("right",)),
            "food": any(w in t for w in ("food", "eat", "fruit")),
            "danger": any(w in t for w in ("danger", "scary", "enemy")),
            "bright": any(w in t for w in ("bright", "light")),
            "dark": any(w in t for w in ("dark", "night")),
        }

    def _demo_decoder(self, s):
        if s["danger"]:
            return "avoid"
        if s["food"]:
            return "approach_food"
        if s["left"] and not s["right"]:
            return "turn_left"
        if s["right"] and not s["left"]:
            return "turn_right"
        if s["bright"]:
            return "explore_light"
        if s["dark"]:
            return "seek_light"
        return "neutral"

    def respond(self, text):
        signals = self._encode_text(text)

        # Placeholder until the exact installed flybrain encoder/decoder
        # interface is wired in. This deliberately says so in the UI.
        state = self._demo_decoder(signals)

        replies = {
            "avoid": "I sense something threatening. I would try to move away.",
            "approach_food": "I detect a food-related cue. I would investigate it.",
            "turn_left": "I would turn left.",
            "turn_right": "I would turn right.",
            "explore_light": "I detect a bright cue and would investigate it.",
            "seek_light": "I detect a dark cue and would look for a brighter area.",
            "neutral": "I don't have a strong sensory cue to act on.",
        }

        return {
            "reply": replies[state],
            "mode": "REAL FLYBRAIN INSTALLED — adapter hookup still required"
                    if self.real_brain_available else
                    "DEMO MODE — install flybrain and wire its encoder/decoder",
            "signals": signals,
            "state": state,
        }
