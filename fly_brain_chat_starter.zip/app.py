from flask import Flask, request, jsonify, render_template
from fly_adapter import FlyBrainAdapter

app = Flask(__name__)
brain = FlyBrainAdapter()

@app.get("/")
def index():
    return render_template("index.html")

@app.post("/chat")
def chat():
    data = request.get_json(force=True) or {}
    message = str(data.get("message", "")).strip()
    if not message:
        return jsonify({"reply": "I didn't sense anything."})

    result = brain.respond(message)
    return jsonify(result)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8000, debug=False)
