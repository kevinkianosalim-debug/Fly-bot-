# Fly Brain Chat

A starter chat interface around the public `fly.ai` / `flybrain` MaleCNS simulation.

Important:
- The connectome is a neural simulation, not a proven conscious copy of a fly.
- The neural simulation itself does not generate English sentences.
- This project therefore uses a small translation layer: your text is converted into structured sensory/interaction signals, those signals can be passed to the fly-brain adapter, and the adapter converts neural output into a small set of fly-like states.
- The `flybrain` package is optional in this starter so you can test the chat UI before downloading the large neural model.

## Requirements

Python 3.12+ is recommended.

## Run

```bash
python -m pip install -r requirements.txt
python app.py
```

Then open http://127.0.0.1:8000 in a browser.

## Enabling the real brain

Install the current package:

```bash
python -m pip install flybrain
```

The public project currently describes a 166,700-neuron, 25.6-million-connection MaleCNS simulation. See:
https://github.com/alextitonis/fly.ai

The adapter in `fly_adapter.py` is deliberately isolated because the project's Python API can change. The chat UI works without pretending that a text chatbot is the neural simulation.

## Architecture

You -> web chat -> app.py -> FlyBrainAdapter -> structured response

The next step is to connect the adapter's `step()` method to the exact encoder/decoder API of the installed `flybrain` version.
