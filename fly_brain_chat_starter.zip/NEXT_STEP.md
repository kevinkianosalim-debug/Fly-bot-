# Connecting the real simulation

This starter intentionally does not invent the upstream API.

1. Install Python 3.12+.
2. Run:
   python -m pip install flybrain
3. Open the installed package's examples/docs and identify the current public
   encoder and decoder entry points.
4. Replace the `_demo_decoder()` section in `fly_adapter.py` with:
   text -> sensory encoder -> brain.step(...) -> descending-neuron activity -> decoder.
5. Keep the chat UI unchanged.

The public README is the source of truth for the current simulation architecture:
https://github.com/alextitonis/fly.ai
